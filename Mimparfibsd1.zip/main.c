#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int fib[10], y = 1, x = 0, z = 0, i = 1, j = 0;

	printf("Introduza o número de um elemento da sequencia de fibonacci (de 0 "
		   "a 9)\n");
	scanf("%d", &j);
	fib[0] = 1;

	while (i < 10) {
		z = y;  // Aux
		y += x; // Fib
		x = z;  // U(n-2)->U(n-1)
		fib[i] = y;
		i++;
	}
	printf("fib(%d) = %d\n", j, fib[j]);
	if ((fib[j] % 2) != 0) {
		fib[j]++;
		printf(
			"Esse número é impar, e o número par maior e mais próximo é %d\n",
			fib[j]);
	} else {
		fib[j] = fib[j] + 2;
		printf(
			"Esse número é par, e o número par maior e mais próximo é %d\n",
			fib[j]);
	}
	return 0;
}